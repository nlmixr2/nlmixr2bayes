ui <- function () 
{
    ini({
        lkin <- c(-2.99573227355399, -0.487386094199027, 2.30258509299405)
        lkout <- c(-3.91202300542815, -0.934385392179047, 1.6094379124341)
        ltau <- fix(0.405465108108164)
        add.sd <- c(0, 0.339818691381869)
        eta.kin ~ 0.0477771110872726
        prior(lkin) ~ dnorm(log(0.7), 0.5)
        prior(lkout) ~ dnorm(log(0.4), 0.5)
        prior(add.sd) ~ dcauchy(0, 1)
    })
    model({
        kin <- exp(lkin + eta.kin)
        kout <- exp(lkout)
        tau <- exp(ltau)
        R(0) <- 1
        d/dt(R) <- kin - kout * delay(R, tau)
        R ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "ddeMod", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

