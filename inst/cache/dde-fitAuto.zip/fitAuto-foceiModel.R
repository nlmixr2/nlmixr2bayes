foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1]);\ncmt(R);\nR(0)=1;\nrx_expr_0~exp(THETA[2]);\nrx_expr_1~ETA[1]+THETA[1];\nrx_expr_2~exp(rx_expr_1);\nd/dt(R)=-rx_expr_0*delay(R,1.5)+rx_expr_2;\nd/dt(rx__sens_R_BY_ETA_1___)=0+rx_expr_2+(-rx_expr_0)*delay(rx__sens_R_BY_ETA_1___,1.5);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=R;\nrx__sens_rx_pred__BY_ETA_1___=rx__sens_R_BY_ETA_1___;\nrx_r_=Rx_pow_di(THETA[3],2);\nrx__sens_rx_r__BY_ETA_1___=0;\ndvid(1);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "R(0)=1\nrx_expr_0~exp(THETA[2])\nrx_expr_1~ETA[1]+THETA[1]\nrx_expr_2~exp(rx_expr_1)\nd/dt(R)=-rx_expr_0*delay(R, 1.5)+rx_expr_2\nd/dt(rx__sens_R_BY_ETA_1___)=0+rx_expr_2+(-rx_expr_0)*delay(rx__sens_R_BY_ETA_1___, 1.5)\nrx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_pred_=R\nrx__sens_rx_pred__BY_ETA_1___=rx__sens_R_BY_ETA_1___\nrx_r_=Rx_pow_di(THETA[3], 2)\nrx__sens_rx_r__BY_ETA_1___=0\nrx__ETA1=ETA[1]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1]);\ncmt(R);\ntau=1.5;\nR(0)=1;\nrx_expr_0~exp(THETA[2]);\nrx_expr_1~ETA[1]+THETA[1];\nrx_expr_2~exp(rx_expr_1);\nd/dt(R)=-rx_expr_0*delay(R,1.5)+rx_expr_2;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=R;\nrx_r_=Rx_pow_di(THETA[3],2);\nlkin=THETA[1];\nlkout=THETA[2];\nadd.sd=THETA[3];\neta.kin=ETA[1];\nkin=rx_expr_2;\nkout=rx_expr_0;\ntad=tad();\ndosenum=dosenum();\ndvid(1);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1]);\ncmt(R);\ntau=1.5;\nR(0)=1;\nd/dt(R)=-exp(THETA[2])*delay(R,1.5)+exp(ETA[1]+THETA[1]);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=R;\nrx_r_=Rx_pow_di(THETA[3],2);\ndvid(1);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L)

foceiModel[["eventEta"]] <- 0L

foceiModel[["eventEtaAll"]] <- 0L

class(foceiModel) <- "foceiModelList"

