phiH <- list(lotri({
    eta.kin ~ 303.746459275712
}), lotri({
    eta.kin ~ 511.345127644115
}), lotri({
    eta.kin ~ 343.421832692535
}), lotri({
    eta.kin ~ 221.762783144459
}), lotri({
    eta.kin ~ 288.848152603958
}), lotri({
    eta.kin ~ 204.733182628698
}), lotri({
    eta.kin ~ 201.978124818045
}), lotri({
    eta.kin ~ 208.486324604869
}), lotri({
    eta.kin ~ 155.123300670403
}), lotri({
    eta.kin ~ 225.706068512317
}), lotri({
    eta.kin ~ 308.744562707058
}), lotri({
    eta.kin ~ 171.158705880213
}))
names(phiH) <- c("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12")
