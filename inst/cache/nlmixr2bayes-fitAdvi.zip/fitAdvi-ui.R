ui <- function () 
{
    ini({
        tka <- 0.428945602
        tcl <- c(-Inf, 1.01724056, 4.60517018598809)
        tv <- 3.43810243
        add.sd <- c(0, 0.77461654)
        eta.ka ~ 0.378319951
        eta.cl ~ 0.0713375133
        eta.v ~ 0.00918907831
        prior(tka) ~ dnorm(0.45, 1)
        prior(tcl) ~ dnorm(1, 1)
        prior(tv) ~ dnorm(3.45, 1)
        prior(add.sd) ~ dcauchy(0, 2.5)
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.cmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

