ui <- function () 
{
    ini({
        tka <- 0.469489056570487
        tcl <- c(-Inf, 1.00991882617141, 4.60517018598809)
        tv <- 3.45136850270312
        add.sd <- c(0, 0.707176942042022)
        eta.ka ~ 0.622678442042082
        eta.cl ~ 0.102325991163798
        eta.v ~ 0.0290588521555774
        prior(tka) ~ dnorm(0.45, 1)
        prior(tcl) ~ dnorm(1, 1)
        prior(tv) ~ dnorm(3.45, 1)
        prior(add.sd) ~ dcauchy(0, 2.5)
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.cmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

