ui <- function () 
{
    ini({
        tka <- 0.467555352346578
        tcl <- c(-Inf, 1.01271027543476, 4.60517018598809)
        tv <- 3.44959301904079
        add.sd <- c(0, 0.707237600477141)
        eta.ka ~ 0.666618543874909
        eta.cl ~ 0.102737924756188
        eta.v ~ 0.0289330225457639
        prior(tka) ~ dnorm(0.45, 1)
        prior(tcl) ~ dnorm(1, 1)
        prior(tv) ~ dnorm(3.45, 1)
        prior(add.sd) ~ dcauchy(0, 2.5)
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.cmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

