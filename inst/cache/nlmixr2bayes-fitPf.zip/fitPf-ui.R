ui <- function () 
{
    ini({
        tka <- 0.243547393370914
        tcl <- c(-Inf, 1.05441074899301, 4.60517018598809)
        tv <- 3.41513806980737
        add.sd <- c(0, 0.651926299203902)
        eta.ka ~ 1.3937349042035
        eta.cl ~ 0.264788070058205
        eta.v ~ 0.0698333848693585
        prior(tka) ~ dnorm(0.45, 1)
        prior(tcl) ~ dnorm(1, 1)
        prior(tv) ~ dnorm(3.45, 1)
        prior(add.sd) ~ dcauchy(0, 2.5)
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.cmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

