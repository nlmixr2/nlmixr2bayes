ui <- function () 
{
    ini({
        tka <- 0.246572353648738
        tcl <- c(-Inf, 1.05551646491378, 4.60517018598809)
        tv <- 3.41439343551031
        add.sd <- c(0, 0.650117418768508)
        eta.ka ~ 1.39164949988954
        eta.cl ~ 0.266037855228546
        eta.v ~ 0.0699486151355303
        prior(tka) ~ dnorm(0.45, 1)
        prior(tcl) ~ dnorm(1, 1)
        prior(tv) ~ dnorm(3.45, 1)
        prior(add.sd) ~ dcauchy(0, 2.5)
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.cmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

